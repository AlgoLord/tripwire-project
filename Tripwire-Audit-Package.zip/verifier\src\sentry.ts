import { ethers } from "ethers";
import * as nacl from "tweetnacl";

export interface PolicyConfig {
  maxEthTransfer: bigint;
  allowedDelegates: string[];
  forbiddenSpenders: string[];
}

export interface TransactionRequest {
  nonce: number;
  to: string;
  value: bigint;
  data: string;
  chainId: number;
  delegate?: string; // For EIP-7702 authorization
  spender?: string;  // For ERC-20 checks
}

export class TripwireSentry {
  private policy: PolicyConfig;
  private verifierKeyPair: nacl.SignKeyPair;

  constructor(policy: PolicyConfig, verifierSecretKey: Uint8Array) {
    this.policy = policy;
    // Ensure the keypair corresponds precisely to the 32-byte public key on-chain
    this.verifierKeyPair = nacl.sign.keyPair.fromSecretKey(verifierSecretKey);
  }

  /**
   * Inspects a transaction against security policies and generates an Ed25519 verdict signature if valid.
   */
  public evaluateAndSign(
    contractNonce: bigint,
    tx: TransactionRequest,
    derivationPath: string
  ): { payloadHash: Uint8Array; signature: Uint8Array } {
    
    // 1. Enforce Max ETH Transfer Policy
    if (tx.value > this.policy.maxEthTransfer) {
      throw new Error(
        `Tripwire Policy Violation: Transaction value ${tx.value.toString()} wei exceeds maximum allowed limit of ${this.policy.maxEthTransfer.toString()} wei.`
      );
    }

    // 2. Enforce Forbidden Spenders Policy
    if (tx.spender && this.policy.forbiddenSpenders.includes(tx.spender.toLowerCase())) {
      throw new Error(`Tripwire Policy Violation: Spender address ${tx.spender} is explicitly forbidden.`);
    }

    // 3. Enforce EIP-7702 Delegate Allowlist (if applicable)
    if (tx.delegate && this.policy.allowedDelegates.length > 0) {
      if (!this.policy.allowedDelegates.includes(tx.delegate.toLowerCase())) {
        throw new Error(`Tripwire Policy Violation: EIP-7702 delegate ${tx.delegate} is not in the allowed delegates list.`);
      }
    }

    // 4. Compute strict EVM unsigned transaction signing digest
    // Constructing standard transaction payload bytes for EVM signing
    const unsignedTx = {
      to: tx.to,
      value: tx.value,
      data: tx.data,
      nonce: tx.nonce,
      chainId: tx.chainId,
    };

    // Serialize and hash using ethers transaction serialization (or keccak256 of payload)
    const serializedTx = ethers.Transaction.from(unsignedTx).unsignedSerialized;
    const payloadHashHex = ethers.keccak256(serializedTx);
    const payloadHash = ethers.getBytes(payloadHashHex);

    // 5. Construct message binding matching the NEAR contract's expected byte order:
    // Message = Nonce (8 bytes LE) + Payload Hash (32 bytes) + Derivation Path (UTF-8 bytes)
    const nonceBuffer = Buffer.alloc(8);
    nonceBuffer.writeBigUInt64LE(contractNonce, 0);

    const pathBytes = Buffer.from(derivationPath, "utf-8");
    
    const message = Buffer.concat([
      nonceBuffer,
      Buffer.from(payloadHash),
      pathBytes,
    ]);

    // 6. Sign the message digest with the verifier Ed25519 private key
    const signature = nacl.sign.detached(message, this.verifierKeyPair.secretKey);

    return {
      payloadHash: payloadHash,
      signature: signature,
    };
  }

  public getPublicKeyBytes(): Uint8Array {
    return this.verifierKeyPair.publicKey;
  }
}