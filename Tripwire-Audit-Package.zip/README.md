\# Tripwire: Transaction Firewall for NEAR Chain Signatures



\## Overview

Tripwire is a secure transaction firewall designed to intercept, evaluate, and authorize Ethereum transactions through NEAR Chain Signatures MPC (`v1.signer-prod.testnet`).



\## Architecture \& Components

\- \*\*`contract/`\*\*: NEAR smart contract written in Rust (`near-sdk` v5) managing state, nonces, proposal records, and Ed25519 signature verification.

\- \*\*`verifier/`\*\*: Off-chain TypeScript verifier (`sentry.ts`) enforcing policy limits (max ETH, forbidden spenders, allowed delegates) and computing EVM transaction digests.



\## Cryptographic Binding

The Ed25519 verdict signature is cryptographically bound using the exact byte layout:

Message = Nonce (8 bytes LE) || Payload Hash (32 bytes) || Derivation Path (UTF-8 bytes)

