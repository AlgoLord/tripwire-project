use near_sdk::borsh::{BorshDeserialize, BorshSerialize};
use near_sdk::serde::{Deserialize, Serialize};
use near_sdk::store::{UnorderedMap, UnorderedSet};
use near_sdk::{
    env, near, promise_result_as_success, AccountId, BorshStorageKey, Gas, NearToken, Promise,
    PublicKey,
};

#[derive(BorshSerialize, BorshDeserialize, Serialize, Deserialize, Clone)]
#[serde(crate = "near_sdk::serde")]
#[borsh(crate = "near_sdk::borsh")]
pub struct PolicyConfig {
    pub max_eth_transfer: near_sdk::json_types::U128,
    pub allowed_delegates: Vec<String>,
    pub forbidden_spenders: Vec<String>,
}

#[derive(BorshSerialize, BorshDeserialize, Serialize, Deserialize, Clone, PartialEq, Debug)]
#[serde(crate = "near_sdk::serde")]
#[borsh(crate = "near_sdk::borsh")]
pub enum ProposalStatus {
    Pending,
    Approved,
    SignatureRequested,
    Completed,
    Failed,
    Rejected,
}

#[derive(BorshSerialize, BorshDeserialize, Serialize, Deserialize, Clone)]
#[serde(crate = "near_sdk::serde")]
#[borsh(crate = "near_sdk::borsh")]
pub struct ProposalRecord {
    pub nonce: u64,
    pub agent_id: AccountId,
    pub payload_hash: [u8; 32],
    pub derivation_path: String,
    pub status: ProposalStatus,
    pub created_at: u64,
}

#[derive(BorshSerialize, BorshDeserialize, BorshStorageKey)]
#[borsh(crate = "near_sdk::borsh")]
pub enum StorageKey {
    ConsumedHashes,
    AuditRecords,
    Proposals,
}
#[near(contract_state)]
pub struct TripwireContract {
    pub owner_id: AccountId,
    pub verifier_pk: PublicKey,
    pub mpc_contract_id: AccountId,
    pub is_paused: bool,
    pub policy: PolicyConfig,
    pub tx_nonce: u64,
    pub consumed_hashes: UnorderedSet<Vec<u8>>,
    pub audit_records: UnorderedMap<u64, ProposalRecord>,
    pub proposals: UnorderedMap<u64, ProposalRecord>,
}

impl Default for TripwireContract {
    fn default() -> Self {
        panic!("Tripwire contract is not initialized");
    }
}

#[near]
impl TripwireContract {
    #[init]
    pub fn new(verifier_pk: PublicKey, mpc_contract_id: AccountId, initial_policy: PolicyConfig) -> Self {
        let pk_bytes = verifier_pk.as_bytes();
        assert_eq!(
            pk_bytes.len(),
            32,
            "Tripwire Error: Verifier public key must be exactly 32 bytes for Ed25519 verification."
        );

        Self {
            owner_id: env::predecessor_account_id(),
            verifier_pk,
            mpc_contract_id,
            is_paused: false,
            policy: initial_policy,
            tx_nonce: 0,
            consumed_hashes: UnorderedSet::new(StorageKey::ConsumedHashes),
            audit_records: UnorderedMap::new(StorageKey::AuditRecords),
            proposals: UnorderedMap::new(StorageKey::Proposals),
        }
    }

    /// Propose a transaction for firewall inspection and tracking
    pub fn propose_transaction(&mut self, payload_hash: [u8; 32], derivation_path: String) -> u64 {
        assert!(!self.is_paused, "Tripwire Error: Contract is paused");
        
        // Validate derivation path security bounds (e.g., must start with an allowed prefix)
        assert!(
            derivation_path.starts_with("eth,"),
            "Tripwire Error: Invalid derivation path namespace."
        );

        self.tx_nonce += 1;
        let nonce = self.tx_nonce;
        let agent_id = env::predecessor_account_id();

        let proposal = ProposalRecord {
            nonce,
            agent_id: agent_id.clone(),
            payload_hash,
            derivation_path,
            status: ProposalStatus::Pending,
            created_at: env::block_timestamp(),
        };

        self.proposals.insert(nonce, proposal);
        
        env::log_str(&format!("Tripwire Proposal Created: nonce={}, agent={}", nonce, agent_id));
        nonce
    }

    /// Execute transaction with valid verifier verdict signature and bonded proposal
    #[payable]
    pub fn execute_with_verdict(
        &mut self,
        nonce: u64,
        payload_hash: [u8; 32],
        derivation_path: String,
        signature: Vec<u8>,
    ) -> Promise {
        assert!(!self.is_paused, "Tripwire Error: Contract is paused");

        // 1. Retrieve and validate pending proposal binding
        let mut proposal = self.proposals.get(&nonce)
            .expect("Tripwire Error: Proposal does not exist")
            .clone();

        assert_eq!(proposal.status, ProposalStatus::Pending, "Tripwire Error: Proposal is not in Pending status");
        assert_eq!(proposal.payload_hash, payload_hash, "Tripwire Error: Payload hash mismatch");
        assert_eq!(proposal.derivation_path, derivation_path, "Tripwire Error: Derivation path mismatch");

        // 2. Construct exact message digest bound to parameters
        let mut message = Vec::new();
        message.extend_from_slice(&nonce.to_le_bytes());
        message.extend_from_slice(&payload_hash);
        message.extend_from_slice(derivation_path.as_bytes());

        // 3. Verify Ed25519 verdict signature from sentry verifier
        let sig_array: &[u8; 64] = signature
            .as_slice()
            .try_into()
            .expect("Tripwire Error: Signature must be exactly 64 bytes");
        
        let pk_array: &[u8; 32] = self.verifier_pk
            .as_bytes()
            .try_into()
            .expect("Tripwire Error: Public key must be exactly 32 bytes");

        let is_valid = env::ed25519_verify(sig_array, &message, pk_array);
        assert!(is_valid, "Tripwire Error: Invalid verifier verdict signature");

        // 4. Update proposal status to Approved & Signature Requested
        proposal.status = ProposalStatus::SignatureRequested;
        self.proposals.insert(nonce, proposal.clone());
        self.audit_records.insert(nonce, proposal);

        // 5. Invoke MPC Chain Signatures cross-contract call with secure gas & deposit
        let attached_deposit = env::attached_deposit();
        assert!(
            attached_deposit >= NearToken::from_yoctonear(1),
            "Tripwire Error: Attached deposit required for MPC cross-contract call"
        );

        let mpc_gas = Gas::from_tgas(150);
        
        let call_promise = Promise::new(self.mpc_contract_id.clone())
            .function_call(
                "sign".to_string(),
                near_sdk::serde_json::json!({
                    "payload": payload_hash,
                    "path": derivation_path,
                    "key_version": 0
                })
                .to_string()
                .into_bytes(),
                attached_deposit,
                mpc_gas,
            );

        let callback_promise = Promise::new(env::current_account_id())
            .function_call(
                "mpc_callback".to_string(),
                near_sdk::serde_json::json!({ "nonce": nonce }).to_string().into_bytes(),
                NearToken::from_near(0),
                Gas::from_tgas(30),
            );

        call_promise.then(callback_promise)
    }

    /// MPC Callback handler to correctly resolve promise lifecycle status
    pub fn mpc_callback(&mut self, nonce: u64) -> bool {
        assert_eq!(env::predecessor_account_id(), env::current_account_id(), "Unauthorized callback");
        
        let mut proposal = self.proposals.get(&nonce).expect("Proposal not found").clone();
        
        if let Some(_success) = promise_result_as_success() {
            proposal.status = ProposalStatus::Completed;
            self.proposals.insert(nonce, proposal.clone());
            self.audit_records.insert(nonce, proposal);
            true
        } else {
            proposal.status = ProposalStatus::Failed;
            self.proposals.insert(nonce, proposal.clone());
            self.audit_records.insert(nonce, proposal);
            false
        }
    }

    /// Read-only view for contract configuration and state
    pub fn get_config(&self) -> near_sdk::serde_json::Value {
        near_sdk::serde_json::json!({
            "owner_id": self.owner_id,
            "verifier_pk": self.verifier_pk,
            "mpc_contract_id": self.mpc_contract_id,
            "is_paused": self.is_paused,
            "policy": self.policy,
            "tx_nonce": self.tx_nonce
        })
    }
}